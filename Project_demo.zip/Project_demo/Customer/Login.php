<?php
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Login</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light" style="background-color:whitesmoke;">
        <div class="container">
            <a class="navbar-brand" href="/Project_demo/">
                <img src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE" height="40" width="40">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/">Home</a>
                    </li>
                    <!-- <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Become Partner
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="/Project_demo/Restaurant/">Add Restaurant</a></li>
                            <li><a class="dropdown-item" href="/Project_demo/Delivery/">Become Delivery Staff</a></li>
                        </ul>
                    </li> -->
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/Customer/Login.php">Login</a>
                    </li> -->
                    <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/Customer/Sign_up.php">Sign up</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php
    if (!empty($_SESSION['errmsg'])) {
        echo "<div class='alert alert-danger alert-dismissible fade show mb-0' role='alert'>
        $_SESSION[errmsg]
        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
        </div>";
        unset($_SESSION['errmsg']);
    }
    ?>

    <section class="vh-100 bg-light">
        <div class="container h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col col-xl-10">
                    <div class="card" style="border-radius: 1rem;">
                        <div class="row g-0">
                            <div class="col-md-6 col-lg-5 d-none d-md-block">
                                <img src="/Project_demo/Image/Img/Customer_Login.jpg" alt="LOGIN photo" class="img-fluid h-100" style="border-radius: 1rem 0 0 1rem;" />
                            </div>
                            <div class="col-md-6 col-lg-7 d-flex align-items-center">
                                <div class="card-body p-4 p-lg-5 text-black">
                                    <form method="POST" action="LoginCheck.php">
                                        <div class="d-flex align-items-center mb-3 pb-1">
                                            <span class="h1 fw-bold mb-0">
                                                <img src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="LOGO" height="100" width="100">
                                            </span>
                                        </div>
                                        <h5 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Sign into your account</h5>
                                        <div class="form-floating mb-4">
                                            <input type="email" name="email" class="form-control" id="floatingInput" placeholder="name@example.com"
                                            value="
                                            <?php
                                                if(isset($_COOKIE['email']))
                                                {
                                                    echo $_COOKIE['email'];
                                                }
                                            ?>
                                            "   
                                            required>
                                            <label for="floatingInput">Email address</label>
                                        </div>
                                        <div class="form-floating mb-2">
                                            <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password" 
                                            required>
                                            <label for="floatingPassword">Password</label>
                                        </div>
                                        <div class="small form-check mb-4">
                                            <input class="form-check-input" type="checkbox" value="Rememberme" id="flexCheckDefault" name="Rememberme" 
                                            <?php
                                            if(isset($_COOKIE['email']) and isset($_COOKIE['password']))
                                            {
                                                echo "checked";
                                            }
                                            ?>>
                                            <label class="form-check-label" for="flexCheckDefault">
                                                Remember me
                                            </label>
                                        </div>
                                        <div class="pt-1 mb-4">
                                            <div class="d-grid gap-2">
                                                <input type="submit" value="Login" class="btn btn-primary" name="btnlogin">
                                            </div>
                                        </div>
                                        <a class="small text-muted text-decoration-none" href="/Project_demo/Forgot_password.php">Forgot password?</a>
                                        <p class="mb-5 pb-lg-2 text-muted">Don't have an account? <a class="text-decoration-none" href="/Project_demo/Customer/Sign_up.php"><strong>Register here</strong></a>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <script> 
    document.getElementById('floatingPassword').value="<?php echo $_COOKIE['password'];?>";
    </script>
</body>

</html>