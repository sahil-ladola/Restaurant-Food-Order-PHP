<div class="modal fade" id="Login" tabindex="-1" aria-labelledby="Login" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="Login">Login</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="row g-3">
                    <div class="input-group input-group-lg">
                        <span class="input-group-text" id="inputGroup-sizing-lg">+91</span>
                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg" placeholder="Mobile Number" maxlength="10">
                    </div>
                    <div class="form-floating col-12">
                        <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
                        <label for="floatingPassword">Password</label>
                    </div>
                    <div class="col-12 my-1">
                        <a href="#" class="text-decoration-none" data-bs-toggle="modal" data-bs-target="#Forgotpass"><small>Forgot password?</small></a>
                    </div>
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="Rememberme">
                            <label class="form-check-label" for="Rememberme">
                                Remember me
                            </label>
                        </div>
                    </div>
                    <a class="text-decoration-none" href="/Project_demo/Customer/Home.php">
                        <div class="d-grid gap-2">
                            <button class="btn btn-primary" type="button">Login</button>
                        </div>
                    </a>
                    <hr>
                    <div class="col-12">
                        Don't have an account? <a class="text-decoration-none" href="#" data-bs-toggle="modal" data-bs-target="#Signup"><strong>Sign up</strong></a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>