<?php
session_start();
if (!isset($_SESSION['Login'])) {
    header('Location:Login.php');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Change Password</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <header class="p-3 border-bottom">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <a href="/Project_demo/Customer/" class="d-flex align-items-center mb-2 mb-lg-0 text-dark text-decoration-none">
                    <img class="bi me-2" width="40" height="40" role="img" src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE">
                </a>

                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                    <li class="nav-item">
                        <a class="nav-link text-decoration-none text-muted" href="/Project_demo/Customer/Home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-decoration-none text-muted" href="/Project_demo/Customer/Order.php">My Orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-decoration-none text-muted" href="/Project_demo/Customer/Logout.php">Logout</a>
                    </li>
                </ul>
                <div class="text-end">
                    <div class="dropdown text-end">
                        <a href="/Project_demo/Customer/AddToCart.php" class="text-decoration-none mx-2">
                            <img src="/Project_demo/Image/Icon/Cart.png" alt="cart" height="20" width="20">
                        </a>
                        <a href="/Project_demo/Customer/profile.php" class="link-dark text-decoration-none">
                            <label for="User" class="px-2 text-secondary"><?php echo $_SESSION['username']; ?></label>
                            <img src="/Project_demo/Image/Icon/User.png" id="User" alt="User" width="32" height="32" class="rounded-circle">
                        </a>
                    </div>
                </div>
            </div>

        </header>
    </div>
    <div class="container text-center mt-3">
        <h1 id="ResetPass">Change Password</h1>
        <form class="row g-3" method="post">
            <div class="form-floating mt-4 col-12">
                <input type="password" class="form-control" id="OldPass" placeholder="Old Password" name="old" required>
                <label for="OldPass">Old Password</label>
            </div>
            <div class="form-floating col-12">
                <input type="password" class="form-control" id="NewPass" placeholder="New Password" name="new" required>
                <label for="NewPass">New Password</label>
            </div>
            <div class="form-floating col-12">
                <input type="password" class="form-control" id="ConfirmNewPass" name="cnew" placeholder="Confirm New Password" required>
                <label for="ConfirmNewPass">Confirm New Password</label>
            </div>
            <div class="d-grid gap-2">
                <input type="submit" name="submit" value="Change Password" class="btn btn-primary">
            </div>
        </form>
    </div>
    <?php
    $conn = mysqli_connect('localhost', 'root', '', 'fd');
    if (!$conn) {
        die("ERROR IN CONNECTION...");
    }

    ob_start();

    if (isset($_POST['submit'])) {
        session_start();
        $Email = $_SESSION['email'];
        $oldpassword = $_POST['old'];
        $newpassword = $_POST['new'];
        $repassword = $_POST['cnew'];

        $query = "select * from tbl_reg where Email='$Email'";
        $result = mysqli_query($conn, $query);
        $num = mysqli_num_rows($result);
        if ($num > 0) {
            while ($row1 = mysqli_fetch_assoc($result)) {
                if (password_verify($oldpassword, $row1['Password'])) {
                    if ($newpassword == $repassword) {
                        $hash = password_hash($newpassword, PASSWORD_DEFAULT);
                        $query1 = "update tbl_reg set password='$hash' where email='$Email'";
                        $r = mysqli_query($conn, $query1);
                        if ($r) {
                            header("Location:/Project_demo/index.php");
                        } else {
                            echo "<script> alert('password does\'t update !! please try again');</script>";
                            header("location:login.php");
                        }
                    } else {
                        echo "<script> alert('Password does\'t match !! please try again');</script>";
                    }
                } else {
                    echo "<script> alert('old Password does\'t match !! please try again');</script>";
                }
            }
        } else {
            echo "<script> alert('no !! please try again'   );</script>";
        }
    }
    ob_flush();
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>