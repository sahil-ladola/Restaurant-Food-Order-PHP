<?php
session_start();
if (!isset($_SESSION['Login'])) {
    header('Location:Login.php');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Menu</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <header class="p-3 border-bottom">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <a href="/Project_demo/Customer/" class="d-flex align-items-center mb-2 mb-lg-0 text-dark text-decoration-none">
                    <img class="bi me-2" width="40" height="40" role="img" src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE">
                </a>

                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                    <li class="nav-item">
                        <a class="nav-link text-decoration-none text-muted" href="/Project_demo/Customer/Home.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-decoration-none text-muted" href="/Project_demo/Customer/Order.php">My Orders</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-decoration-none text-muted" href="/Project_demo/Customer/Logout.php">Logout</a>
                    </li>
                </ul>
                <div class="text-end">

                    <div class="dropdown text-end">
                        <a href="/Project_demo/Customer/AddToCart.php" class="text-decoration-none mx-2">
                            <img src="/Project_demo/Image/Icon/Cart.png" alt="cart" height="20" width="20">
                        </a>
                        <a href="/Project_demo/Customer/profile.php" class="link-dark text-decoration-none">
                            <label for="User" class="px-2 text-secondary"><?php echo $_SESSION['username']; ?></label>
                            <img src="/Project_demo/Image/Icon/User.png" id="User" alt="User" width="32" height="32" class="rounded-circle">
                        </a>
                    </div>
                </div>
            </div>

        </header>
        <nav aria-label="breadcrumb">
            <small>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a class="text-decoration-none text-dark" href="/Project_demo/index.php">Home</a></li>
                    <li class="breadcrumb-item">India</li>
                    <li class="breadcrumb-item">Surat</li>
                    <li class="breadcrumb-item">Mota Varachha</li>
                    <li class="breadcrumb-item active">Mahesh Pav bhaji</li>
                </ol>
            </small>
        </nav>
    </div>
    <div id="carouselExampleDark" class="carousel carousel-dark slide " data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="/Project_demo/Image/Img/Menu.jpg" class="d-block w-100" alt="Slide 1" style="height:70vh">
                <!-- <div class="carousel-caption d-none d-md-block v-center mb-5">
                    <h5 class="mb-5 display-3 fw-bolder text-white">Cart</h5>
                    <p class="mb-5 display-6 text-white"><small>Your cart list</small></p>
                </div> -->
            </div>
        </div>
    </div>
    <div class="container text-center mt-3">
        <div class="row justify-content-md-center">
            <div class="col-md-auto">
                <h1 class="border-bottom p-3">Menu</h1>
                <div class="container text-center">
                    <div class="row">
                        <div class="col-12">
                            <div class="container text-center m-3">
                                <div class="row m-3">
                                    <div class="col">
                                        <img src="/Project_demo/Image/Img/home_Mahesh Pav Bhaji.jpg" alt="Image" height="100" width="150">
                                    </div>
                                    <div class="col-6 text-start">
                                        <h4>Pav Bhaji</h4>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat, esse!</p>
                                    </div>
                                    <div class="col fw-bold">
                                        120.00/-
                                    </div>
                                    <div class="col">
                                        <input type="text" class="form-control-sm ms-5" value="1" size="1" name="quantity">
                                        <a href="/Project_demo/Customer/AddToCart.php">
                                            <input type="button" value="Add to Cart" class="mt-1 btn btn-outline-danger">
                                        </a>
                                    </div>
                                </div>
                                <div class="row m-3">
                                    <div class="col">
                                        <img src="/Project_demo/Image/Img/home_Mahesh Pav Bhaji.jpg" alt="Image" height="100" width="150">
                                    </div>
                                    <div class="col-6 text-start">
                                        <h4>Pav Bhaji</h4>
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Placeat, esse!</p>
                                    </div>
                                    <div class="col fw-bold">
                                        120.00/-
                                    </div>
                                    <div class="col">
                                        <input type="text" class="form-control-sm ms-5" value="1" size="1" name="quantity">
                                        <a href="/Project_demo/Customer/AddToCart.php">
                                            <input type="button" value="Add to Cart" class="mt-1 btn btn-outline-danger">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FOOTER -->
    <?php
    require "C:/xampp/htdocs/Project_demo/Customer/Footer.php";
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>