<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "fd");
if (!$con) {
    die("not connect");
}

if (isset($_POST['btn_reg'])) {
    $q = "select * from tbl_reg where Email='$_POST[email]'";
    $result = mysqli_query($con, $q);
    if (mysqli_num_rows($result)) {
        $_SESSION['errmsg'] = "Email Address is already exists.";
        header('location:/Project_demo/Customer/Sign_up.php');
    } else {
        $_SESSION['reg'] = 'True';
        // $_SESSION['rid'] = $_POST['R_id'];
        $_SESSION['fname'] = $_POST['fname'];
        $_SESSION['lname'] = $_POST['lname'];
        $_SESSION['con_num'] = $_POST['mobnum'];
        $_SESSION['address'] = $_POST['address'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['password'] = $_POST['password'];

        $pass = $_POST['password'];
        $uppercase = preg_match('@[A-Z]@', $pass);
        $lowercase = preg_match('@[a-z]@', $pass);
        $number = preg_match('@[0-9]@', $pass);
        $specialChars = preg_match('@[^\w]@', $pass);


        if (!$uppercase || !$lowercase || !$number || !$specialChars || strlen($pass) < 8) {
            $_SESSION['errmsg'] = 'Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
            header('location:/Project_demo/Customer/Sign_up.php');
        } else {
            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $q = "insert into tbl_reg values(null,'$_SESSION[fname]','$_SESSION[lname]',$_SESSION[con_num],'$_SESSION[address]','$_SESSION[email]','$hash')";
            $r = mysqli_query($con, $q);
            if ($r) {
                header('location:/Project_demo/Customer/Login.php');
            }
        }

        // if (preg_match("/^[a-zA-z]*$/", $_SESSION['fname'])) {
        //     if (preg_match("/^[a-zA-z]*$/", $_SESSION['lname'])) {
        //         if (preg_match("/^[0-9]*$/", $_SESSION['con_num'])) {
        //         } else {
        //             $invalid_connum = true;
        //         }
        //     } else {
        //         $invalid_lname = true;
        //     }
        // } else {
        //     $invalid_fname = true;
        // }
        // if ($invalid_connum && $invalid_lname && $invalid_fname) {
        //     $_SESSION['errmsg'] = "Only alphabets are allowed in first name , last name and Only numbers are allowed in Contact number";
        //     header('location:/Project_demo/Customer/Sign_up.php');
        // } else if ($invalid_lname && $invalid_fname) {
        //     $_SESSION['errmsg'] = "Only alphabets are allowed in first name , last name.";
        //     header('location:/Project_demo/Customer/Sign_up.php');
        // } else if ($invalid_connum && $invalid_lname) {
        //     $_SESSION['errmsg'] = "Only alphabets are allowed in last name and Only numbers are allowed in Contact number";
        //     header('location:/Project_demo/Customer/Sign_up.php');
        // } else if ($invalid_fname && $invalid_connum) {
        //     $_SESSION['errmsg'] = "Only alphabets are allowed in first name and Only numbers are allowed in Contact number";
        //     header('location:/Project_demo/Customer/Sign_up.php');
        // } else if ($invalid_fname) {
        //     $_SESSION['errmsg'] = "Only alphabets are allowed in first name.";
        //     header('location:/Project_demo/Customer/Sign_up.php');
        // } else if ($invalid_connum) {
        //     $_SESSION['errmsg'] = "Only numbers are allowed in Contact number.";
        //     header('location:/Project_demo/Customer/Sign_up.php');
        // } else if ($invalid_lname) {
        //     $_SESSION['errmsg'] = "Only alphabets are allowed in last name.";
        //     header('location:/Project_demo/Customer/Sign_up.php');
        // }
    }
}
