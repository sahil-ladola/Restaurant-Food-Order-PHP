<?php
session_start();
if (!isset($_SESSION['Login'])) {
    header('Location:Login.php');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Placed Order</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar bg-light">
        <div class="container">
            <a class="navbar-brand" href="/Project_demo/Customer/PlaceOrder.php">
                <img class="bi me-2" width="40" height="40" role="img" src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE">
            </a>
        </div>
    </nav>
    <div class="px-4 text-center my-3">
        <img class="d-block mx-auto" src="/Project_demo/Image/Icon/success.png" alt="FOODIVE" width="100" height="100">
        <h1 class="display-5 fw-bold mb-3">Your order placed successfully.</h1>
        <div class="col-lg-6 mx-auto mb-4">
            <p class="lead">Placed order details mentioned below.</p>
        </div>
    </div>
    <div class="container px-4">
        <table class="table table-hover border-none">
            <tbody>
                <tr>
                    <th class="text-end">First Name :</th>
                    <td class="text-start">Sahil</td>
                    <th class="text-end">Last Name :</th>
                    <td class="text-start">Ladola</td>
                </tr>
                <tr>
                    <th class="text-end">Email Address : </th>
                    <td class="text-start">Sahilladola18@gmail.com</td>
                    <th class="text-end">Contact number :</th>
                    <td class="text-start">1234567890</td>
                </tr>
                <tr>
                    <th class="text-end">Address : </th>
                    <td colspan="3">x-101, twin tower , varchha , surat.</td>
                </tr>
            </tbody>
        </table>


        <table class="table table-bordered mt-3 table-hover">
            <thead class="bg-dark text-white">
                <tr>
                    <th scope="col">Item</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Price</th>
                    <!-- <th scope="col">Status</th> -->
                    <th scope="col">Date and Time</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="row">
                        <h4>PIZZA</h4>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </th>
                    <td>2</td>
                    <td>500.00/-</td>
                    <!-- <td>On the way</td> -->
                    <td>2022-09-01 10:00:57</td>
                </tr>
            </tbody>
        </table>
        <a href="/Project_demo/Customer/Home.php" class="text-decoration-none">
            <div class="d-grid gap-2 col-6 mx-auto mt-4">
                <button class="btn btn-outline-success" type="button">Continue Ordering</button>
            </div>
        </a>
    </div>

    <!-- FOOTER -->
    <?php
    require "C:/xampp/htdocs/Project_demo/Customer/Footer.php";
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>