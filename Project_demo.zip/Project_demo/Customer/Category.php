<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <header class="p-3 border-bottom">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <a href="/Project_demo/Customer/" class="d-flex align-items-center mb-2 mb-lg-0 text-dark text-decoration-none">
                    <img class="bi me-2" width="40" height="40" role="img" src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE">
                </a>

                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                </ul>

                <div class="nav form-group mx-2">
                    <div class="input-group shadow-sm">
                        <label class="input-group-text" for="Search">
                            <img src="/Project_demo/Image/Icon/Search.png" alt="Search" height="20" width="20">
                        </label>
                        <input type="text" class="form-control" id="Search" placeholder="Search for Food">
                    </div>
                </div>

                <div class="text-end">

                    <div class="dropdown text-end">
                        <a href="/Project_demo/Customer/AddToCart.php" class="text-decoration-none mx-2">
                            <img src="/Project_demo/Image/Icon/Cart.png" alt="cart" height="20" width="20">
                        </a>
                        <a href="#" class="link-dark text-decoration-none">
                            <label for="User" class="px-2 text-secondary">Username</label>
                            <img src="/Project_demo/Image/Icon/User.png" id="User" alt="User" width="32" height="32" class="rounded-circle">
                        </a>
                    </div>
                </div>
            </div>

        </header>
        <nav aria-label="breadcrumb">
            <small>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a class="text-decoration-none text-dark" href="/Project_demo/index.php">Home</a></li>
                    <li class="breadcrumb-item">India</li>
                    <li class="breadcrumb-item">Surat</li>
                    <li class="breadcrumb-item active" aria-current="page">Mota Varachha</li>
                </ol>
            </small>
        </nav>
    </div>
    <div class="container-fluid">
        <div class="sticky-top bg-white">
            <div class="container">
                <div class="d-flex flex-row mb-3">
                    <div class="py-2">
                        <button type="button" class="btn btn-outline-light text-secondary disabled border rounded-5">Filters</button>
                    </div>
                    <div class="p-2">
                        <a href="/Project_demo/Customer/Category.php">
                            <button type="button" class="btn btn-outline-light text-secondary border rounded-5">Rating: 4+</button>
                        </a>
                    </div>

                    <div class="p-2">
                        <a href="/Project_demo/Customer/Category.php">
                            <button type="button" class="btn btn-outline-light text-secondary border rounded-5">Pure Veg</button>
                        </a>
                    </div>
                    <div class="p-2">
                        <a href="/Project_demo/Customer/Category.php">
                            <button type="button" class="btn btn-outline-light text-secondary border rounded-5">Non Veg</button>
                        </a>
                    </div>
                    <div class="p-2">
                        <a href="# ">
                            <button type="button" class="btn btn-outline-light text-secondary border rounded-5">More Filters</button>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-light">
            <div class="container">
                <h3 class="fw-bold py-3">Order food near you</h3>
                <div class="container">
                    <div class="row g-4">
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/ " class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_Mahesh Pav Bhaji.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">Mahesh Pav Bhaji</h5>
                                        <p>Lorem ipsum dolor sit amet consectetur</p>
                                    </div>
                                </a>
                                <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/5star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/ " class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_McDonald's.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">McDonald's</h5>
                                        <p>Lorem ipsum dolor sit amet consectetur</p>
                                    </div>
                                </a>
                                <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/3star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/ " class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_La Pino'z Pizza.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">La Pino'z Pizza</h5>
                                        <p>Lorem ipsum dolor sit amet</p>
                                    </div>
                                </a>
                                <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/4star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/ " class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_Burger King.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">Burger King</h5>
                                        <p>Lorem ipsum dolor</p>
                                    </div>
                                </a>
                                <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/2star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/ " class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_Wok On Fire.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">Wok On Fire</h5>
                                        <p>Lorem ipsum dolor sit amet consectetur</p>
                                    </div>
                                </a>
                                <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/4star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/ " class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_Omlet.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">Egg Omlet</h5>
                                        <p>Lorem ipsum dolor sit amet</p>
                                    </div>
                                </a>
                                <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/5star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FOOTER -->
    <?php
    require "C:/xampp/htdocs/Project_demo/Customer/Footer.php";
    ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>