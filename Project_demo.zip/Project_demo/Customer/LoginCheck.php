<?php
session_start();
require "C:/xampp/htdocs/Project_demo/Conn.php";
if (isset($_POST['btnlogin'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $q = "select Fname , email , password , R_id from tbl_reg where email='$email'";
    $r = mysqli_query($con, $q);
    if (mysqli_num_rows($r) > 0) {
        $row = mysqli_fetch_assoc($r);
        if ($row['email'] == $email) {
            if (password_verify($password, $row['password'])) {
                $_SESSION['Login'] = true;
                $_SESSION['reg_id'] = $row['R_id'];
                $_SESSION['username'] = $row['Fname'];
                $_SESSION['email'] = $email;
                if (isset($_POST['Rememberme'])) {
                    $hour = time() + 3600 * 24 * 30;
                    setcookie('email', $email, $hour);
                    setcookie('password', $password, $hour);
                }
                else
                {
                    setcookie('email', " ", time()-3600);
                    setcookie('password', "", time()-3600);   
                }
                header('Location:/Project_demo/Customer/afterlogin.php');
            } else {
                $_SESSION['errmsg'] = "Invalid password";
                header('Location:/Project_demo/Customer/Login.php');
            }
        }
    } else {
        $_SESSION['errmsg'] = "Email and password is invalid";
        header('Location:/Project_demo/Customer/Login.php');
    }
}
