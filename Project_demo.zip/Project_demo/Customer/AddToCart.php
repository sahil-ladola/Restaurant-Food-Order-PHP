<?php
session_start();
if (!isset($_SESSION['Login'])) {
    header('Location:Login.php');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Cart</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <header class="p-3 border-bottom">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <a href="/Project_demo/Customer" class="d-flex align-items-center mb-2 mb-lg-0 text-dark text-decoration-none">
                    <img class="bi me-2" width="40" height="40" role="img" src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE">
                </a>

                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                    <li><a href="/Project_demo/Customer/Home.php" class="nav-link px-2 text-secondary">Home</a></li>
                    <li><a href="/Project_demo/Customer/Order.php" class="nav-link px-2 text-secondary">My Orders</a></li>
                    <li><a href="/Project_demo/Customer/Logout.php" class="nav-link px-2 text-secondary">Logout</a></li>
                </ul>

                <div class="text-end">
                    <div class="dropdown text-end">
                        <a href="profile.php" class="text-decoration-none">
                            <label for="User" class="px-2 text-secondary"><?php echo $_SESSION['username']; ?></label>
                            <img src="/Project_demo/Image/Icon/User.png" id="User" alt="User" width="32" height="32" class="rounded-circle">
                        </a>
                    </div>
                </div>
            </div>
        </header>
    </div>
    <div id="carouselExampleDark" class="carousel carousel-dark slide " data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="/Project_demo/Image/Img/AddToCart.jpg" class="d-block w-100" alt="Slide 1" style="height:70vh">
                <div class="carousel-caption d-none d-md-block v-center mb-5">
                    <h5 class="mb-5 display-3 fw-bolder text-white">Cart</h5>
                    <p class="mb-5 display-6 text-white"><small>Your cart list</small></p>
                </div>
            </div>
        </div>
    </div>
    <div class="container my-5">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Product</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total</th>
                    <th scope="col">Delete</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <tr class="align-middle">
                    <td>
                        <img class="border rounded me-2" src="/Project_demo/Image/Img/home_sandwich.jpg" alt="sandwich" width="70" height="70">
                        Cheese grill sandwich
                        Lorem, ipsum dolor.
                    </td>
                    <td>100.00</td>
                    <td class="w-25">
                        <input type="number" name="quantity" class="w-50" value="1">
                    </td>
                    <td>100.00</td>
                    <td>
                        <button class="btn btn-danger">
                            <img src="/Project_demo/Image/Icon/delete.png" alt="Del" height="20" width="20">
                        </button>
                    </td>
                </tr>
                <tr class="align-middle">
                    <td>
                        <img class="border rounded me-2" src="/Project_demo/Image/Img/home_burger.jpg" alt="burger" width="70" height="70">
                        Burger
                        Lorem, ipsum dolor.
                    </td>
                    <td>80.00</td>
                    <td class="w-25">
                        <input type="number" name="quantity" class="w-50" value="2">
                    </td>
                    <td>160.00</td>
                    <td>
                        <button class="btn btn-danger">
                            <img src="/Project_demo/Image/Icon/delete.png" alt="Del" height="20" width="20">
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="container">
        <!-- <div class="input-group my-3 w-50 shadow-sm">
            <input type="text" class="form-control form-control-lg" placeholder="Coupon Code">
            <button class="btn btn-outline-info btn-lg" type="button">Apply Coupon</button>
        </div> -->
    </div>
    <div class="container">
        <div class="card w-100 shadow-sm">
            <div class="card-header text-muted">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            Total Amount :
                        </div>
                        <div class="col text-end">
                            260.00
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="card-body text-muted">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            Coupon code discount :
                        </div>
                        <div class="col text-end">
                            52.00
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="card-footer">
                <!-- <div class="container">
                    <div class="row">
                        <div class="col">
                            Payable amount :
                        </div>
                        <div class="col text-end">
                            260.00
                        </div>
                    </div>
                </div> -->
                <a href="/Project_demo/Customer/PlaceOrder.php">
                    <div class="d-grid gap-2">
                        <!-- <div id="liveAlertPlaceholder"></div> -->
                        <button type="button" class="btn btn-primary">Checkout</button>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <!-- FOOTER -->
    <?php
    require "C:/xampp/htdocs/Project_demo/Customer/Footer.php";
    ?>

    <!-- <script>
        const alertPlaceholder = document.getElementById('liveAlertPlaceholder')

        const alert = (message, type) => {
            const wrapper = document.createElement('div')
            wrapper.innerHTML = [
                `<div class="alert alert-${type} alert-dismissible fade show mt-2" role="alert">`,
                `   <div>${message}</div>`,
                '   <a href="/Project_demo/Customer/Home.php"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></a>',
                '</div>'
            ].join('')

            alertPlaceholder.append(wrapper)
        }

        const alertTrigger = document.getElementById('liveAlertBtn')
        if (alertTrigger) {
            alertTrigger.addEventListener('click', () => {
                alert('Your order placed successfully.', 'success')
            })
        }
    </script> -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>