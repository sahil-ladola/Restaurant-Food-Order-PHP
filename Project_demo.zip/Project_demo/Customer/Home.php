<?php
session_start();
if (!isset($_SESSION['Login'])) {
    header('Location:Login.php');
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Home</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <header class="p-3 border-bottom">
            <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
                <a href="/Project_demo/Customer/" class="d-flex align-items-center mb-2 mb-lg-0 text-dark text-decoration-none">
                    <img class="bi me-2" width="40" height="40" role="img" src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE">
                </a>

                <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
                    <!-- <li><a href="#Category" class="nav-link px-2 text-secondary">Category</a></li> -->
                    <li><a href="#Restaurant" class="nav-link px-2 text-secondary">Restaurant</a></li>
                    <li><a href="/Project_demo/Customer/Order.php" class="nav-link px-2 text-secondary">My Orders</a></li>
                    <li><a href="/Project_demo/Customer/Logout.php" class="nav-link px-2 text-secondary">Logout</a></li>
                </ul>

                <div class="nav form-group mx-2">
                    <div class="input-group shadow-sm">
                        <label class="input-group-text" for="Search">
                            <img src="/Project_demo/Image/Icon/Search.png" alt="Search" height="20" width="20">
                        </label>
                        <input type="text" class="form-control" id="Search" placeholder="Search for Food">
                    </div>
                </div>

                <div class="text-end">
                    <div class="dropdown text-end">
                        <a href="/Project_demo/Customer/AddToCart.php" class="text-decoration-none mx-2">
                            <img src="/Project_demo/Image/Icon/Cart.png" alt="cart" height="20" width="20">
                        </a>
                        <a href="profile.php" class="text-decoration-none">
                            <label for="User" class="px-2 text-secondary"><?php echo $_SESSION['username']; ?></label>
                            <img src="/Project_demo/Image/Icon/User.png" id="User" alt="User" width="32" height="32" class="rounded-circle">
                        </a>
                    </div>
                </div>
            </div>
        </header>
        <nav aria-label="breadcrumb">
            <small>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">Home</li>
                    <li class="breadcrumb-item">India</li>
                    <li class="breadcrumb-item">Surat</li>
                    <li class="breadcrumb-item active">Mota Varachha</li>
                </ol>
            </small>
        </nav>
    </div>
    <div class="container-fluid">
        <!-- <div class="sticky-top bg-white">
            <div class="container">
                <div class="d-flex flex-row mb-3">
                    <div class="py-2">
                        <button type="button" class="btn btn-outline-light text-secondary disabled border rounded-5">Filters</button>
                    </div>
                    <div class="p-2">
                        <a href="/Project_demo/Customer/Category.php">
                            <button type="button" class="btn btn-outline-light text-secondary border rounded-5">Rating: 4+</button>
                        </a>
                    </div>

                    <div class="p-2">
                        <a href="/Project_demo/Customer/Category.php">
                            <button type="button" class="btn btn-outline-light text-secondary border rounded-5">Pure Veg</button>
                        </a>
                    </div>
                    <div class="p-2">
                        <a href="/Project_demo/Customer/Category.php">
                            <button type="button" class="btn btn-outline-light text-secondary border rounded-5">Non Veg</button>
                        </a>
                    </div>
                    <div class="p-2">
                        <a href="#">
                            <button type="button" class="btn btn-outline-light text-secondary border rounded-5">More Filters</button>
                        </a>
                    </div>
                </div>
            </div>
        </div> -->
        <!-- <div class="bg-light">
            <div class="container" id="Category">
                <h3 class="fw-bold py-3">Eat your favorite category food.</h3>
                <div class="row row-cols-2 row-cols-lg-6 g-2 g-lg-3 p-3 ">
                    <div class="col">
                        <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                            <div class="text-center">
                                <img src="/Project_demo/Image/Img/home_pizza.jpg" class="rounded-circle" height=120px width=120px alt="Lapinoz">
                                <p class="m-2 fs-5">Pizza</p>
                            </div>
                        </a>
                    </div>
                    <div class="col">
                        <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                            <div class="text-center">
                                <img src="/Project_demo/Image/Img/home_snacks.jpg" class="rounded-circle" height=120px width=120px alt="Lapinoz">
                                <p class="m-2 fs-5">Snacks</p>
                            </div>
                        </a>
                    </div>
                    <div class="col">
                        <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                            <div class="text-center">
                                <img src="/Project_demo/Image/Img/home_sandwich.jpg" class="rounded-circle" height=120px width=120px alt="Lapinoz">
                                <p class="m-2 fs-5">Sandwich</p>
                            </div>
                        </a>
                    </div>
                    <div class="col">
                        <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                            <div class="text-center">
                                <img src="/Project_demo/Image/Img/home_burger.jpg" class="rounded-circle" height=120px width=120px alt="Lapinoz">
                                <p class="m-2 fs-5">Burger</p>
                            </div>
                        </a>
                    </div>
                    <div class="col">
                        <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                            <div class="text-center">
                                <img src="/Project_demo/Image/Img/home_egg.jpg" class="rounded-circle" height=120px width=120px alt="Lapinoz">
                                <p class="m-2 fs-5">Egg</p>
                            </div>
                        </a>
                    </div>
                    <div class="col">
                        <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                            <div class="text-center">
                                <img src="/Project_demo/Image/Img/home_fries.jpg" class="rounded-circle" height=120px width=120px alt="Lapinoz">
                                <p class="m-2 fs-5">Fries</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div> -->
        <div class="container" id="Restaurant">
            <h3 class="fw-bold py-3">Popular restaurant partners</h3>
            <div class="row row-cols-2 row-cols-lg-6 g-2 g-lg-3 p-3">
                <div class="col">
                    <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                        <div class="text-center">
                            <img src="/Project_demo/Image/Img/Lapinoz.avif" height=120px width=120px alt="La Pino'z Pizza">
                            <p class="m-3 fs-6">La Pino'z Pizza</p>
                        </div>
                    </a>
                </div>
                <div class="col">
                    <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                        <div class="text-center">
                            <img src="/Project_demo/Image/Img/McD.avif" height=120px width=120px alt="McDonald's">
                            <p class="m-3 fs-6">McDonald's</p>
                        </div>
                    </a>
                </div>
                <div class="col">
                    <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                        <div class="text-center">
                            <img src="/Project_demo/Image/Img/Subway.avif" height=120px width=120px alt="Subway">
                            <p class="m-3 fs-6">Subway</p>
                        </div>
                    </a>
                </div>
                <div class="col">
                    <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                        <div class="text-center">
                            <img src="/Project_demo/Image/Img/BurgerKing.avif" height=120px width=120px alt="Burger King">
                            <p class="m-3 fs-6">Burger King</p>
                        </div>
                    </a>
                </div>
                <div class="col">
                    <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                        <div class="text-center">
                            <img src="/Project_demo/Image/Img/Dominoz.avif" height=120px width=120px alt="Domino's Pizza">
                            <p class="m-3 fs-6">Domino's Pizza</p>
                        </div>
                    </a>
                </div>
                <div class="col">
                    <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-secondary">
                        <div class="text-center">
                            <img src="/Project_demo/Image/Img/Trishiv.avif" height=120px width=120px alt="Trishiv Chinese Corner">
                            <p class="m-3 fs-6">Trishiv Chinese Corner</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <div class="bg-light">
            <div class="container">
                <!-- <h3 class="fw-bold py-3">Order food near you</h3> -->
                <div class="container">
                    <div class="row g-4">
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_Mahesh Pav Bhaji.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">Mahesh Pav Bhaji</h5>
                                        <p>Lorem ipsum dolor sit amet consectetur</p>
                                    </div>
                                </a>
                                <!-- <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/5star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul> -->
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_McDonald's.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">McDonald's</h5>
                                        <p>Lorem ipsum dolor sit amet consectetur</p>
                                    </div>
                                </a>
                                <!-- <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/3star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul> -->
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_La Pino'z Pizza.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">La Pino'z Pizza</h5>
                                        <p>Lorem ipsum dolor sit amet</p>
                                    </div>
                                </a>
                                <!-- <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/4star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul> -->
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_Burger King.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">Burger King</h5>
                                        <p>Lorem ipsum dolor</p>
                                    </div>
                                </a>
                                <!-- <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/2star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul> -->
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_Wok On Fire.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">Wok On Fire</h5>
                                        <p>Lorem ipsum dolor sit amet consectetur</p>
                                    </div>
                                </a>
                                <!-- <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/4star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul> -->
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width: 22rem;">
                                <a href="/Project_demo/Customer/Menu.php" class="text-decoration-none text-body">
                                    <img src="/Project_demo/Image/Img/home_Omlet.jpg" class="card-img-top" alt="Pav Bhaji" height="280" width="350">
                                    <div class="card-body">
                                        <h5 class="card-title">Egg Omlet</h5>
                                        <p>Lorem ipsum dolor sit amet</p>
                                    </div>
                                </a>
                                <!-- <ul class="list-group list-group-flush text-center">
                                    <li class="list-group-item">
                                        <img src="/Project_demo/Image/Icon/5star.png" alt="5" height="50" width="50">
                                    </li>
                                    <li class="list-group-item">
                                        <div class="d-grid">
                                            <button class="btn btn-outline-danger" type="button">Add to favorite</button>
                                        </div>
                                    </li>
                                </ul> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FOOTER -->
    <?php
    require "C:/xampp/htdocs/Project_demo/Customer/Footer.php";
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>