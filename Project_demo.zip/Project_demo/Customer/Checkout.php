<div class="modal fade" id="Checkout" tabindex="-1" aria-labelledby="CheckoutLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="CheckoutLabel">Billing address</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row g-3">
                        <div class="form-floating col-md-6">
                            <input type="text" class="form-control" id="floatingInput" placeholder="First Name">
                            <label for="floatingInput">First Name</label>
                        </div>
                        <div class="form-floating col-md-6">
                            <input type="text" class="form-control" id="floatingInput" placeholder="Last Name">
                            <label for="floatingInput">Last Name</label>
                        </div>
                        <div class="form-floating col-12">
                            <input type="text" class="form-control" id="floatingInputAddress" placeholder="Address">
                            <label for="floatingInputAddress">Address</label>
                        </div>
                        <div class="form-floating col-12">
                            <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                            <label for="floatingInput">Email address</label>
                        </div>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text" id="inputGroup-sizing-lg">+91</span>
                            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg" placeholder="Mobile Number" maxlength="10">
                        </div>
                        <a class="text-decoration-none" href="/Project_demo/Customer/Home.php">
                            <div class="d-grid gap-2">
                                <button class="btn btn-primary" type="button">Place Order</button>
                            </div>
                        </a>
                    </form>
                </div>
            </div>
        </div>
    </div>