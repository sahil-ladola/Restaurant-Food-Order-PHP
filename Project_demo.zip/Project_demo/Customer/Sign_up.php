<div class="modal fade" id="Signup" tabindex="-1" aria-labelledby="Signup" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="Signup">Sign up</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form class="row g-3">
                    <div class="form-floating col-md-6">
                        <input type="text" class="form-control" id="floatingInput" placeholder="First Name">
                        <label for="floatingInput">First Name</label>
                    </div>
                    <div class="form-floating col-md-6">
                        <input type="text" class="form-control" id="floatingInput" placeholder="Last Name">
                        <label for="floatingInput">Last Name</label>
                    </div>
                    <div class="input-group input-group-lg">
                        <span class="input-group-text" id="inputGroup-sizing-lg">@</span>
                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg" placeholder="Username">
                    </div>

                    <div class="form-floating col-12">
                        <input type="text" class="form-control" id="floatingInputAddress" placeholder="Address">
                        <label for="floatingInputAddress">Address</label>
                    </div>
                    <div class="form-floating col-12">
                        <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                        <label for="floatingInput">Email address</label>
                    </div>
                    <div class="input-group input-group-lg">
                        <span class="input-group-text" id="inputGroup-sizing-lg">+91</span>
                        <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg" placeholder="Mobile Number" maxlength="10">
                    </div>
                    <div class="form-floating col-12">
                        <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
                        <label for="floatingPassword">Password</label>
                    </div>
                    <div class="col-12">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="agree">
                            <label class="form-check-label" for="agree"><small>
                                    I agree to FOODIVE's
                                    <strong>Terms of Service</strong> ,
                                    <strong>Privacy Policy</strong> and
                                    <strong>Content Policies.</strong></small>
                            </label>
                        </div>

                    </div>
                    <a class="text-decoration-none" href="#" data-bs-toggle="modal" data-bs-target="#Login">
                        <div class="d-grid gap-2">
                            <button class="btn btn-primary" type="button">Create Account</button>
                        </div>
                    </a>
                    <hr>
                    <div class="col-12">
                        Already have an account? <a class="text-decoration-none" href="#" data-bs-toggle="modal" data-bs-target="#Login"><strong>Login</strong></a>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>