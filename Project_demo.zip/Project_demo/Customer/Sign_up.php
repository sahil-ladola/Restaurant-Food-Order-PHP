<?php
session_start();
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Sign Up</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        .card-registration .select-input.form-control[readonly]:not([disabled]) {
            font-size: 1rem;
            line-height: 2.15;
            padding-left: .75em;
            padding-right: .75em;
        }

        .card-registration .select-arrow {
            top: 13px;
        }
    </style>
</head>

<body onload="fillup()">
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color:whitesmoke;">
        <div class="container">
            <a class="navbar-brand" href="/Project_demo/">
                <img src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE" height="40" width="40">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/">Home</a>
                    </li>
                    <!-- <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Become Partner
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="/Project_demo/Restaurant/">Add Restaurant</a></li>
                            <li><a class="dropdown-item" href="/Project_demo/Delivery/">Become Delivery Staff</a></li>
                        </ul>
                    </li> -->
                    <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/Customer/Login.php">Login</a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/Customer/Sign_up.php">Sign up</a>
                    </li> -->
                </ul>
            </div>
        </div>
    </nav>
    <?php
    if (!empty($_SESSION['errmsg'])) {
        echo "<div class='alert alert-danger alert-dismissible fade show mb-0' role='alert'>
        $_SESSION[errmsg]
        <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
        </div>";
        unset($_SESSION['errmsg']);
    }
    ?>
    <section class="h-100 bg-light">
        <div class="container h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col">
                    <div class="card card-registration my-4">
                        <div class="row g-0">
                            <div class="col-xl-6 d-none d-xl-block">
                                <img src="/Project_demo/Image/Img/Customer_SignUp.jpg" alt="SIGN UP photo" class="img-fluid" style="border-top-left-radius: .25rem; border-bottom-left-radius: .25rem;" />
                            </div>
                            <div class="col-xl-6">
                                <div class="card-body p-md-5 mt-5 text-black">
                                    <h3 class="mb-5 text-uppercase border-bottom">Sign up</h3>
                                    <form method="post" name="form1"action="reg_check.php">
                                        <div class="row">
                                            <div class="col-md-6 mb-4">
                                                <div class="form-floating">
                                                <!-- onfocusout="validateInput(document.form1.fname)" -->
                                                    <input type="text" name="fname" class="form-control" id="fname" placeholder="First Name" required>
                                                    <label for="floatingInput">First Name</label>
                                                </div>
                                            </div>
                                            <div class="col-md-6 mb-4">
                                                <div class="form-floating">
                                                    <input type="text" name="lname" class="form-control" id="floatingInput" placeholder="Last Name" required>
                                                    <label for="floatingInput">Last Name</label>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- <div class="row">
                                        <div class="input-group input-group-lg mb-4">
                                            <span class="input-group-text" id="inputGroup-sizing-lg">@</span>
                                            <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg" placeholder="Username">
                                        </div>
                                    </div> -->

                                        <div class="form-floating mb-4">
                                            <input type="text" class="form-control" name="address" id="floatingInputAddress" placeholder="Address" required>
                                            <label for="floatingInputAddress">Address</label>
                                        </div>

                                        <div class="d-md-flex justify-content-start align-items-center mb-4">
                                            <div class="form-floating col-12">
                                                <input type="email" class="form-control" name="email" id="floatingInput" placeholder="name@example.com" required>
                                                <label for="floatingInput">Email address</label>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="input-group input-group-lg mb-4">
                                                <span class="input-group-text" id="inputGroup-sizing-lg">+91</span>
                                                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg" name="mobnum" placeholder="Mobile Number" maxlength="10" required>
                                            </div>
                                            <div class="form-floating mb-4">
                                                <input type="password" class="form-control" name="password" id="floatingInputPassword" placeholder="Password" required>
                                                <label for="floatingInputPassword">Create Password</label>
                                            </div>
                                        </div>

                                        <!-- <a class="text-decoration-none" href="/Project_demo/Customer/Home.php"> -->
                                        <div class="d-grid gap-2 mb-4">
                                            <!-- <button class="btn btn-primary" name="btn_reg" type="button">Sign Up</button> -->
                                            <input type="submit" value="Create Account" class="btn btn-primary" name="btn_reg">
                                        </div>
                                        <!-- </a> -->

                                        <div class="col-12">
                                            <p class="text-muted">Already have an account?<a class="text-decoration-none" href="/Project_demo/Customer/Login.php"><strong> Login</strong></a></p>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        // function validateInput() {
        //     var x = document.getElementById("fname");
        //     
        // }
        // function validateInput(inputtxt) {
        //     var letters = /^[A-Za-z]+$/;
        //     if (inputtxt.value.match(letters)) {
        //         // alert('Your name have accepted : you can try another');
        //         return true;
        //     } else {
        //         alert('Please input alphabet characters only');
        //         return false;
        //     }
        // }

        // function fillup() {
        //     document.getElementById('fname').value = " ?>";
        // }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>