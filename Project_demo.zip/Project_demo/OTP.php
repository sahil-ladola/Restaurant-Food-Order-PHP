<div class="container mt-4 text-center" id="OTP" style="visibility:hidden;">
    <h1>OTP</h1>
    <div class="input-container mt-3 text-center">
        <input type="text" class="inputotp text-center" maxlength="1">
        <input type="text" class="inputotp text-center" maxlength="1">
        <input type="text" class="inputotp text-center" maxlength="1">
        <input type="text" class="inputotp text-center" maxlength="1">
        <input type="text" class="inputotp text-center" maxlength="1">
        <input type="text" class="inputotp text-center" maxlength="1">
    </div>
    <a href="/Project_demo/ResetPass.php">
        <button class="btn btn-outline-primary mt-3" type="button">Verify</button>
    </a>
</div>