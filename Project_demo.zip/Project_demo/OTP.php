<div class="modal fade" id="OTP" tabindex="-1" aria-labelledby="OTP" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="OTP">OTP</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="input-container text-center">
                    <input type="text" class="inputotp text-center" maxlength="1">
                    <input type="text" class="inputotp text-center" maxlength="1">
                    <input type="text" class="inputotp text-center" maxlength="1">
                    <input type="text" class="inputotp text-center" maxlength="1">
                    <input type="text" class="inputotp text-center" maxlength="1">
                    <input type="text" class="inputotp text-center" maxlength="1">
                </div>
                <a href="#" class="text-decoration-none">
                    <div class="d-grid gap-2 mt-3">
                        <button class="btn btn-outline-primary" type="button">Verify</button>
                    </div>
                </a>
            </div>

        </div>
    </div>
</div>