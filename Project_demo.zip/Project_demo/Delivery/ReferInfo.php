<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Referring Person Information</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <style>
        <?php
        require "C:/xampp/htdocs/Project_demo/CSS/OTP.css";
        ?>
    </style>
</head>

<body>
    <nav class="navbar sticky-top bg-light">
        <div class="container">
            <a class="navbar-brand" href="/Project_demo/index.php">
                <img src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE" height="40" width="40">
            </a>
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link text-body" href="/Project_demo/index.php">Home</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container mt-5">
        <div class="position-relative m-4">
            <div class="progress" style="height: 1px;">
                <div class="progress-bar bg-success" role="progressbar" aria-label="Progress" style="width: 100%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <a href="/Project_demo/Delivery/StaffInfo.php" class="text-decoration-none">
                <button type="button" class="position-absolute top-0 start-0 translate-middle btn btn-sm btn-success rounded-pill" style="width: 2rem; height:2rem;">1</button>
            </a>
            <button type="button" class="position-absolute top-0 start-100 translate-middle btn btn-sm btn-primary rounded-pill" style="width: 2rem; height:2rem;">2</button>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col">
                <h3>Your Details</h3>
            </div>
            <div class="col text-end">
                <h3>Referring person details</h3>
            </div>
        </div>
        <div class="container">
            <div class="row gx-5">
                <div class="col">
                    <div class="form-floating my-3">
                        <input type="text" class="form-control" id="Fname" placeholder="First Name">
                        <label for="Fname">First Name</label>
                    </div>
                </div>
                <div class="col">
                    <div class="form-floating my-3">
                        <input type="text" class="form-control" id="Lname" placeholder="Last Name">
                        <label for="Lname">Last Name</label>
                    </div>
                </div>
            </div>
            <div class="input-group flex-nowrap input-group-lg mb-3">
                <span class="input-group-text" id="addon-wrapping">+91</span>
                <input type="text" class="form-control" placeholder="Mobile number" aria-label="Mobile number" aria-describedby="addon-wrapping" maxlength="10">
            </div>
            <a class="text-decoration-none" href="#" data-bs-toggle="modal" data-bs-target="#OTP">
                <div class="d-grid gap-2 mb-3">
                    <button class="btn btn-primary" type="button">Verify</button>
                </div>
            </a>
            <small class="text-start text-muted">If you selected for job then you will get your ID and Password Soon through your Email.</small>    
        </div>
    
    </div>
    <div class="container">
        <nav class="navbar fixed-bottom bg-light">
            <div class="container">
                <a href="/Project_demo/Delivery/StaffInfo.php"><button class="btn btn-outline-secondary btn-lg">Go Back</button></a>
                <a href="#"><button class="btn btn-success btn-lg">Done</button></a>
            </div>
        </nav>
    </div>

    <div class="modal fade" id="OTP" tabindex="-1" aria-labelledby="OTP" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="OTP">OTP</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="input-container text-center">
                        <input type="text" class="inputotp text-center" maxlength="1">
                        <input type="text" class="inputotp text-center" maxlength="1">
                        <input type="text" class="inputotp text-center" maxlength="1">
                        <input type="text" class="inputotp text-center" maxlength="1">
                        <input type="text" class="inputotp text-center" maxlength="1">
                        <input type="text" class="inputotp text-center" maxlength="1">
                    </div>
                    <div class="d-grid gap-2 mt-3">
                        <button class="btn btn-outline-primary " data-bs-dismiss="modal" type="button">Verify</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>