<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Become Delivery Staff</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar sticky-top bg-light">
        <div class="container">
            <a class="navbar-brand" href="/Project_demo/index.php">
                <img src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE" height="40" width="40">
            </a>
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link text-body" href="/Project_demo/index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-body" href="#SignUp">Sign Up</a>
                </li>
            </ul>
        </div>
    </nav>
    <div id="carouselExampleDark" class="carousel carousel-dark slide " data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="3000">
                <img src="/Project_demo/Image/Img/Delivery.jpg" class="d-block w-100" alt="Slide 1" style="height:90vh;opacity: 0.9;">
                <div class="carousel-caption d-none d-md-block v-center mb-5">
                    <h1 class="mb-3">We don't accept job application</h1>
                    <p class="mb-1">We don't accept job application directly , we only accept application through employee referrals. If you know someone in our delivery staff then reach out to them and ask them to refer you.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container text-center my-5">
        <div class="row ">
            <div class="col">
                <img src="/Project_demo/Image/Img/Delivery-card.jpg" class="border rounded shadow" alt="Delivery_card" height="300">
            </div>
            <div class="col">
                <h1 class="pt-5">Delivery food to more people on time</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus molestias amet hic esse. Quaerat vitae, voluptates, quas perspiciatis esse pariatur rerum minima eligendi at dicta voluptate quo facere quibusdam et.</p>
            </div>
        </div>
    </div>
    <div class="px-4 py-5 my-5 text-center" id="SignUp">
        <img class="d-block mx-auto mb-4" src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE" width="200" height="200">
        <h1 class="display-5 fw-bold">Sign up</h1>
        <div class="col-lg-6 mx-auto">
            <p class="lead mb-4">Sign up form , If someone referral you already!! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nobis, asperiores!</p>
            <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                <a href="/Project_demo/Delivery/StaffInfo.php">
                    <button type="button" class="btn btn-outline-primary btn-lg px-4 gap-3">Register</button>
                </a>
            </div>
        </div>
    </div>
    <!-- FOOTER -->
    <?php
    require "C:/xampp/htdocs/Project_demo/Customer/Footer.php";
    ?>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>