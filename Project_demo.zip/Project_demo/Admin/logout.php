<?php
session_start();
session_destroy();
$url = 'Login.php';
header('Location: ' . $url);

?>