<?php
session_start();
require "C:/xampp/htdocs/Project_demo/Conn.php";
if (isset($_POST['btnAdminLogin'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $q = "select username , password from admin where username='$username'";
    $r = mysqli_query($con, $q);
    if (mysqli_num_rows($r) > 0) {
        $row = mysqli_fetch_assoc($r);
        if ($row['username'] == $username) {
            if (password_verify($password, $row['password'])) {
                $_SESSION["adm_id"]=$row['id'];
                header('location:/Project_demo/Admin/dashboard.php');
            } else {
                echo "Invalid password";
            }
        }
    } else {
        echo "username and password is invalid";
    }
}
?>