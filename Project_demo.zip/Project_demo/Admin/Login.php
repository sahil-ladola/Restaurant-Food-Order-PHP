<!doctype html>
<html lang="en">
<!-- adminFOODIVE -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="/Project_demo/Admin/assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="/Project_demo/Admin/assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="/Project_demo/Admin/assets/css/style.css" rel="stylesheet">

    <title>FOODIVE | Admin Login</title>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <section class="form-01-main">
        <div class="form-cover">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-sub-main">
                            <div class="_main_head_as">
                                <a href="/Project_demo/Admin/Login.php">
                                    <img src="/Project_demo/Image/Icon/User.png">
                                </a>
                            </div>
                            <form action="CheckLogin.php" method="post">
                                <div class="form-group">
                                    <input id="Username" name="username" class="form-control _ge_de_ol" type="text" placeholder="Username" aria-required="true" required>
                                </div>

                                <div class="form-group">
                                    <input id="password" type="password" class="form-control" name="password" placeholder="Password" required>
                                </div>

                                <div class="form-group">
                                    <div class="check_box_main">
                                        <a href="#" class="pas-text text-decoration-none">Forgot Password ?</a>
                                    </div>
                                </div>

                                <div class="form-group mt-4 d-grid gap-2">
                                    <input type="submit" value="LOGIN" name="btnAdminLogin" class="btn btn-success">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>