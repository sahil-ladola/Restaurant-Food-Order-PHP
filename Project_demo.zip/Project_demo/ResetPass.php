<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>FOODIVE | Reset Password</title>
    <link rel="shortcut icon" href="/Project_demo/Image/Favicon/Favicon.png" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light" style="background-color:whitesmoke;">
        <div class="container">
            <a class="navbar-brand" href="/Project_demo/">
                <img src="/Project_demo/Image/LOGO/foodive-logos_black.png" alt="FOODIVE" height="40" width="40">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/">Home</a>
                    </li> -->
                    <!-- <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Become Partner
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="/Project_demo/Restaurant/">Add Restaurant</a></li>
                            <li><a class="dropdown-item" href="/Project_demo/Delivery/">Become Delivery Staff</a></li>
                        </ul>
                    </li> -->
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/Customer/Login.php">Login</a>
                    </li> -->
                    <!-- <li class="nav-item">
                        <a class="nav-link" href="/Project_demo/Customer/Sign_up.php">Sign up</a>
                    </li> -->
                </ul>
            </div>
        </div>
    </nav>
    <div class="container text-center mt-3">
        <h1 id="ResetPass">Reset Password</h1>
        <form class="row g-3" action="/Project_demo/Customer/Login.php">
            <div class="form-floating mt-4 col-12">
                <input type="password" class="form-control" id="NewPass" placeholder="New Password" required>
                <label for="NewPass">New Password</label>
            </div>
            <div class="form-floating col-12">
                <input type="password" class="form-control" id="ConfirmNewPass" placeholder="Confirm New Password" required>
                <label for="ConfirmNewPass">Confirm New Password</label>
            </div>
            <div class="d-grid gap-2">
                <input type="submit" value="Reset Password" class="btn btn-primary">
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>