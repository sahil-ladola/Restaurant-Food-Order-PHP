<?php
        $con=mysqli_connect("localhost","root","","fd");
        if(!$con)
        {
            die("not connect");
        }
?>